<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - OtakAtik Academy</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fadeIn 0.6s ease-out;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-pending { background: #fef3c7; color: #d97706; }
        .status-paid { background: #d1fae5; color: #065f46; }
        .status-cancelled { background: #fee2e2; color: #dc2626; }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-600 to-purple-700 min-h-screen">
    
    <!-- Navbar -->
    <nav class="bg-white shadow-md fixed w-full top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <!-- Logo -->
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                    <span class="text-white font-bold text-lg">O</span>
                </div>
                <span class="text-xl font-bold text-gray-800">OtakAtik Admin</span>
            </div>
            
            <!-- Menu -->
            <div class="hidden md:flex items-center gap-8">
                <a href="/admin/dashboard" class="text-orange-500 font-medium transition">Dashboard</a>
                <a href="/admin/courses" class="text-gray-700 hover:text-orange-500 font-medium transition">All Courses</a>
                <a href="/admin/users" class="text-gray-700 hover:text-orange-500 font-medium transition">Users</a>
                <a href="/dashboard" class="text-gray-700 hover:text-orange-500 font-medium transition">Back to Site</a>
            </div>
            
            <!-- User Info -->
            <div class="flex items-center gap-4">
                <span class="text-gray-700 font-medium">Admin: {{ Auth::user()->name }}</span>
                <form action="/logout" method="POST">
                    @csrf
                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white font-bold px-4 py-2 rounded-lg transition-all">
                        Logout
                    </button>
                </form>
            </div>
        </div>
    </nav>

    <!-- Admin Dashboard Section -->
    <section class="pt-32 pb-20 px-6">
        <div class="max-w-7xl mx-auto">
            <!-- Header -->
            <div class="text-center mb-12 animate-fade-in">
                <h1 class="text-4xl font-bold text-white mb-4">Admin Dashboard</h1>
                <p class="text-white/80 text-lg">Manage your academy efficiently</p>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                <!-- Participants / Users -->
                <div class="glass-card rounded-2xl p-6 text-white">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm opacity-90">Participants / Users</p>
                            <p class="text-3xl font-bold mt-2">{{ $stats['total_users'] }}</p>
                        </div>
                        <i class="fas fa-users text-2xl opacity-80"></i>
                    </div>
                </div>

                <!-- Financial Analytics -->
                <div class="glass-card rounded-2xl p-6 text-white">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm opacity-90">Financial Analytics</p>
                            <p class="text-3xl font-bold mt-2">Rp{{ number_format($stats['total_revenue'], 0, ',', '.') }}</p>
                        </div>
                        <i class="fas fa-chart-line text-2xl opacity-80"></i>
                    </div>
                </div>

                <!-- Total Courses -->
                <div class="glass-card rounded-2xl p-6 text-white">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm opacity-90">Total Courses</p>
                            <p class="text-3xl font-bold mt-2">{{ $stats['total_courses'] }}</p>
                        </div>
                        <i class="fas fa-book-open text-2xl opacity-80"></i>
                    </div>
                </div>

                <!-- Active Courses -->
                <div class="glass-card rounded-2xl p-6 text-white">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm opacity-90">Paid Courses</p>
                            <p class="text-3xl font-bold mt-2">{{ $stats['paid_courses'] }}</p>
                        </div>
                        <i class="fas fa-check-circle text-2xl opacity-80"></i>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Recent Registrations -->
                <div class="bg-white rounded-2xl shadow-lg p-6 animate-fade-in">
                    <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                        <i class="fas fa-clock text-orange-500"></i>
                        Recent Registrations
                    </h3>
                    
                    <div class="space-y-4">
                        @forelse($recent_registrations as $registration)
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                                    <span class="text-white font-bold text-sm">{{ substr($registration->user->name, 0, 1) }}</span>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-800">{{ $registration->user->name }}</p>
                                    <p class="text-sm text-gray-600">{{ $registration->course }}</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <span class="status-badge status-{{ $registration->status }}">
                                    {{ ucfirst($registration->status) }}
                                </span>
                                <p class="text-sm text-gray-500 mt-1">{{ $registration->created_at->format('M d') }}</p>
                            </div>
                        </div>
                        @empty
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-book-open text-3xl mb-3 opacity-50"></i>
                            <p>No recent registrations</p>
                        </div>
                        @endforelse
                    </div>

                    <div class="mt-6 text-center">
                        <a href="/admin/courses" class="text-orange-500 hover:text-orange-600 font-medium">
                            View All Courses →
                        </a>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-white rounded-2xl shadow-lg p-6 animate-fade-in">
                    <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                        <i class="fas fa-bolt text-orange-500"></i>
                        Quick Actions
                    </h3>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <a href="/admin/courses" class="p-4 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition-colors">
                            <i class="fas fa-book text-blue-500 text-2xl mb-2"></i>
                            <p class="font-medium text-blue-800">Manage Courses</p>
                        </a>
                        
                        <a href="/admin/users" class="p-4 bg-green-50 rounded-lg text-center hover:bg-green-100 transition-colors">
                            <i class="fas fa-users text-green-500 text-2xl mb-2"></i>
                            <p class="font-medium text-green-800">Manage Users</p>
                        </a>
                        
                        <a href="/admin/courses?status=pending" class="p-4 bg-yellow-50 rounded-lg text-center hover:bg-yellow-100 transition-colors">
                            <i class="fas fa-clock text-yellow-500 text-2xl mb-2"></i>
                            <p class="font-medium text-yellow-800">Pending Payments</p>
                        </a>
                        
                        <a href="/admin/courses/export" class="p-4 bg-purple-50 rounded-lg text-center hover:bg-purple-100 transition-colors">
                            <i class="fas fa-download text-purple-500 text-2xl mb-2"></i>
                            <p class="font-medium text-purple-800">Export Data</p>
                        </a>
                    </div>

                    <!-- Financial Summary -->
                    <div class="mt-6 p-4 bg-gradient-to-r from-green-500 to-green-600 rounded-lg text-white">
                        <h4 class="font-bold mb-2">Financial Summary</h4>
                        <div class="flex justify-between items-center">
                            <span>Total Revenue:</span>
                            <span class="font-bold">Rp{{ number_format($stats['total_revenue'], 0, ',', '.') }}</span>
                        </div>
                        <div class="flex justify-between items-center mt-2">
                            <span>Pending Payments:</span>
                            <span class="font-bold">{{ $stats['pending_courses'] }} courses</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Popular Courses -->
            <div class="mt-8 bg-white rounded-2xl shadow-lg p-6 animate-fade-in">
                <h3 class="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <i class="fas fa-chart-bar text-orange-500"></i>
                    Popular Courses
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    @foreach($popular_courses as $course)
                    <div class="p-4 bg-gray-50 rounded-lg">
                        <div class="flex justify-between items-center">
                            <span class="font-medium text-gray-800">{{ $course->course }}</span>
                            <span class="bg-orange-500 text-white px-2 py-1 rounded-full text-sm">
                                {{ $course->count }}
                            </span>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-white py-8 px-6">
        <div class="max-w-7xl mx-auto text-center">
            <p class="text-gray-600">&copy; 2025 OtakAtik Academy. Admin Dashboard</p>
        </div>
    </footer>

    <!-- Success Message Handler -->
    @if(session('success'))
    <div class="fixed top-20 right-6 bg-green-500 text-white px-6 py-4 rounded-lg shadow-2xl z-50 animate-fade-in flex items-center gap-3">
        <i class="fas fa-check-circle"></i>
        <span class="font-medium">{{ session('success') }}</span>
    </div>
    <script>
        setTimeout(() => {
            const alert = document.querySelector('.fixed.top-20');
            if(alert) alert.remove();
        }, 5000);
    </script>
    @endif

</body>
</html>