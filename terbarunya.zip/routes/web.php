<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CourseController;
use Illuminate\Support\Facades\Route;

// Home Route
Route::get('/', function () {
    return view('dashboard');
});

// Public Routes
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/course', [CourseController::class, 'showCourse'])->name('course');

// Auth Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

// Protected Routes (Require Authentication)
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    
    // Course Routes
    Route::get('/course-dashboard', [CourseController::class, 'dashboard'])->name('course.dashboard');
    Route::get('/my-courses', [CourseController::class, 'myCourses'])->name('my-courses');
    Route::post('/course/register', [CourseController::class, 'register'])->name('course.register');
    Route::get('/course/{id}', [CourseController::class, 'show'])->name('course.show');
    Route::delete('/course/{id}', [CourseController::class, 'destroy'])->name('course.destroy');
});

// Admin Routes (Require Admin Privileges)
Route::middleware(['auth', 'admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('/users', [AdminController::class, 'users'])->name('admin.users');
    Route::put('/users/{id}/role', [AdminController::class, 'updateUserRole'])->name('admin.users.role');
    Route::delete('/users/{id}', [AdminController::class, 'deleteUser'])->name('admin.users.delete');
    
    // Course routes (using CourseController)
    Route::get('/courses', [CourseController::class, 'index'])->name('admin.courses');
    Route::put('/courses/{id}/status', [CourseController::class, 'updateStatus'])->name('admin.courses.status');
    Route::get('/courses/export', [CourseController::class, 'export'])->name('admin.courses.export');
});