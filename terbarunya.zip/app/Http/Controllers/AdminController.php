<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\CourseRegistration;

class AdminController extends Controller
{
    /**
     * Show admin dashboard
     */
    public function dashboard()
    {
        // Only allow admin access
        if (!Auth::check() || !Auth::user()->is_admin) {
            abort(403, 'Unauthorized access.');
        }

        $stats = [
            'total_users' => User::count(),
            'total_courses' => CourseRegistration::count(),
            'pending_courses' => CourseRegistration::where('status', 'pending')->count(),
            'paid_courses' => CourseRegistration::where('status', 'paid')->count(),
            'cancelled_courses' => CourseRegistration::where('status', 'cancelled')->count(),
            'total_revenue' => CourseRegistration::where('status', 'paid')->sum('price'),
        ];

        $recent_registrations = CourseRegistration::with('user')
            ->latest()
            ->take(5)
            ->get();

        $popular_courses = CourseRegistration::select('course')
            ->selectRaw('COUNT(*) as count')
            ->groupBy('course')
            ->orderBy('count', 'desc')
            ->get();

        return view('admin.dashboard', compact('stats', 'recent_registrations', 'popular_courses'));
    }

    /**
     * Show all users
     */
    public function users()
    {
        if (!Auth::check() || !Auth::user()->is_admin) {
            abort(403, 'Unauthorized access.');
        }

        $users = User::latest()->paginate(10);

        return view('admin.users', compact('users'));
    }

    /**
     * Update user role
     */
    public function updateUserRole(Request $request, $id)
    {
        if (!Auth::check() || !Auth::user()->is_admin) {
            abort(403, 'Unauthorized access.');
        }

        $user = User::findOrFail($id);
        
        $request->validate([
            'is_admin' => 'required|boolean'
        ]);

        $user->update(['is_admin' => $request->is_admin]);

        return back()->with('success', 'User role updated successfully!');
    }

    /**
     * Delete user
     */
    public function deleteUser($id)
    {
        if (!Auth::check() || !Auth::user()->is_admin) {
            abort(403, 'Unauthorized access.');
        }

        $user = User::findOrFail($id);
        
        // Prevent admin from deleting themselves
        if ($user->id === Auth::id()) {
            return back()->with('error', 'You cannot delete your own account!');
        }

        $user->delete();

        return back()->with('success', 'User deleted successfully!');
    }
}